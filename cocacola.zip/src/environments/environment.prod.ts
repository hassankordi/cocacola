export const environment = {
  production: true,
  sourceUrl: 'http://cocafda.tccbce.com/plc/api',
  sourceTest: 'https://localhost:44370/api',
};
