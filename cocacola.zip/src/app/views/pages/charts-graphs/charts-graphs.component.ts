import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-charts-graphs',
  templateUrl: './charts-graphs.component.html'
})
export class ChartsGraphsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
