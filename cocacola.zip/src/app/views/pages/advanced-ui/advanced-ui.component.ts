import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-advanced-ui',
  templateUrl: './advanced-ui.component.html'
})
export class AdvancedUiComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
